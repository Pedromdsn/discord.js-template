import { Command } from "../features/commands";

const start: Command = (e) => {
  e.reply("Pong!");
}

export default start
